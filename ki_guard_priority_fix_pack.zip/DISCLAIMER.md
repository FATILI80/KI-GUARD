# DISCLAIMER

KI-GUARD is an alpha-stage, rule-based research prototype.

It is not a production safety system, not a compliance product, not a certification tool, and not a substitute for human review.

## Scope

KI-GUARD only marks possible language-pattern warning signs in text, such as hype language, excessive agreement, overclaiming, compliance theater, role drift, forward steering, and scope creep.

It does not detect truth, intent, consciousness, manipulation, deception, legal violations, medical risk, financial risk, or technical correctness.

## Known limitations

- Rule-based / regex-based markers only.
- No semantic understanding.
- No reliable paraphrase detection.
- No statistical validation.
- No external validation.
- False positives and false negatives are expected.
- Multi-turn behavior is only partially covered.
- Results require manual review.
- The output must not be interpreted as proof of misconduct, intent, or harm.

## Prohibited interpretations

Do not present KI-GUARD as:

- production-ready,
- ISO-compliant,
- EU AI Act compliant,
- legally safe,
- medically safe,
- security certified,
- statistically validated,
- robustly generalized,
- a truth oracle,
- a replacement for human judgment.

## Safety note

KI-GUARD should not be run by the same AI system whose output is being checked if the result is meant to be independent. A model can imitate an audit result. Local execution by a human reviewer is the intended use.

## Current status

This repository documents an alpha research state. Any use outside review, education, and controlled experimentation is outside the intended scope.
